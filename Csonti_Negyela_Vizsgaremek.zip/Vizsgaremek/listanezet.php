<?php
require_once("dbconnect.php");

$hiba = "";
$uzenet = "";
$filter = "";

// Teendő mentése
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitTeendo"])) {
    try {
        if (empty($_POST["teendo"]) && empty($_POST["hatarido"])) {
            throw new Exception("Kérjük, adjon meg egy teendőt és egy határidőt!");
        }

        $sqlTeendo = "INSERT INTO lista (listaelem, hatarido) VALUES (:teendo, :hatarido)";
        $queryTeendo = $dbconn->prepare($sqlTeendo);
        $queryTeendo->bindParam("teendo", $_POST["teendo"], PDO::PARAM_STR);
        $queryTeendo->bindParam("hatarido", $_POST["hatarido"], PDO::PARAM_STR);

        $queryTeendo->execute();

        $uzenet = "A teendő sikeresen el lett mentve.";
    } catch (PDOException $e) {
        $hiba = "Teendő mentési hiba: " . $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    } catch (Exception $e) {
        $hiba = $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    }
}

// Szűrő alkalmazása
if (isset($_POST["filter"])) {
    $filter = $_POST["filter"];
}

try {
    $sqlLista = "SELECT id, listaelem, hatarido FROM lista"; // ID hozzáadva
   
    // Szűrés alkalmazása
    if (!empty($filter)) {
        $sqlLista .= " WHERE listaelem LIKE :filter";
    }
   
    // Rendezés a legközelebbi vagy legrégebbi határidő szerint
    if (isset($_POST["sort"]) && $_POST["sort"] == "legkozelebbi") {
        $sqlLista .= " ORDER BY hatarido ASC";
    } elseif (isset($_POST["sort"]) && $_POST["sort"] == "legrégebbi") {
        $sqlLista .= " ORDER BY hatarido DESC";
    } else {
        $sqlLista .= " ORDER BY id ASC"; // Alapértelmezett rendezés
    }
 
    $queryLista = $dbconn->prepare($sqlLista);
    if (!empty($filter)) {
        $queryLista->bindValue("filter", $filter . '%', PDO::PARAM_STR);
    }
    $queryLista->execute();
    $listaelemek = $queryLista->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $hiba = "Listaelemek lekérdezési hiba: " . $e->getMessage();
    error_log($hiba . PHP_EOL, 3, LOGFILE);
}
 
// Feladat törlése
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitTorles"])) {
    $teendoId = $_POST["teendoId"];
    try {
        $sqlTorles = "DELETE FROM lista WHERE id = :id";
        $queryTorles = $dbconn->prepare($sqlTorles);
        $queryTorles->bindParam("id", $teendoId, PDO::PARAM_INT);
        $queryTorles->execute();
       
        $uzenet = "A feladat sikeresen törölve lett.";
    } catch (PDOException $e) {
        $hiba = "Feladat törlési hiba: " . $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teendők Lista</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Teendők Lista</h2>
        <?php
        if (!empty($hiba)) {
            echo "<div class=\"error\">$hiba</div>\n";
        }
        if (!empty($uzenet)) {
            echo "<div class=\"uzenet\">$uzenet</div>\n";
        }
        ?>
       
        <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
            <input type="text" name="teendo" placeholder="Teendő megadása" required>
        <h4>határidő megadása:</h4>
        <input type="date" name="hatarido" placeholder="Határidő" required class="ment2 ">
        <br>
        <input type="submit" value="Mentés" name="submitTeendo" class="ment2">
        
        </form>

        <h3>Szűrő:</h3>
        <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
            <select name="filter">
                <option value="">Válassz egy betűt</option>
                <?php foreach (range('A', 'Z') as $letter): ?>
                    <option value="<?= $letter ?>" <?= ($filter == $letter) ? 'selected' : '' ?>><?= $letter ?></option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Szűrés"class="ment2">
        </form>

        <h3>Rendezés:</h3>
        <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
            <input type="hidden" name="filter" value="<?= $filter ?>">
            <select name="sort">
                <option value="">Válassz rendezési módot</option>
                <option value="legkozelebbi">Legközelebbi határidő</option>
                <option value="legrégebbi">Legrégebbi határidő</option>
            </select>
            <input type="submit" value="Rendezés" class="ment2">
        </form>
        <div class="ment2">
        <h3>Listaelemek:</h3>
        <ul class="liststyle">
    <?php foreach ($listaelemek as $elem): ?>
        <li>
            <a href="teendo_leiras.php?id=<?= $elem['id'] ?>"  style="text-decoration:none">
                <?= htmlspecialchars($elem['listaelem']) ?> - Határidő: <?= htmlspecialchars($elem['hatarido']) ?>
            </a>
            <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post" style="display:table;">
                <input type="hidden" name="teendoId" value="<?= $elem['id'] ?>">
                <input type="submit" value="Törlés" name="submitTorles"  onclick="return confirm('Biztosan törölni szeretné a feladatot?');">
            </form>
        </li>
    <?php endforeach; ?>
</ul>
        </div>
    </div>
</body>
</html>