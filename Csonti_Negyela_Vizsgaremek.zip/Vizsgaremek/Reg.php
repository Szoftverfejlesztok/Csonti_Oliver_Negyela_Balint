<?php
require_once("dbconnect.php");
$hiba = "";
$uzenet = "";
class HibaException extends Exception{}
try {
    $sqlStudio = "SELECT id,felhasznalonev,jelszo FROM felhasznalok";
    $queryStudio = $dbconn->prepare($sqlStudio);
    $queryStudio->execute();
    $studiok = $queryStudio->fetchAll();  
  } catch (PDOException $e){
    $hiba = "Stúdió lekérdezési hiba: ".$e->getMessage();
    error_log($hiba.PHP_EOL,3,LOGFILE);
  }
 
 
 
 
 
 
  if (!empty($dbconn) &&
  $_SERVER["REQUEST_METHOD"] == "POST" &&
  isset($_POST["submitRegisztracio"])) {
  try {
      if (empty($_POST["felhasznalonev"]) || empty($_POST["jelszo"]) || empty($_POST["jelszoUjra"])) {
          throw new HibaException("Kérem minden adatot adjon meg!");
      }
      $sqlUjfilm = "INSERT INTO felhasznalok (felhasznalonev,jelszo) VALUES (:felhasznalonev, :jelszo)";
      $queryUjfilm = $dbconn->prepare($sqlUjfilm);
      $queryUjfilm->bindParam("felhasznalonev", $_POST["felhasznalonev"], PDO::PARAM_STR);
      if ($_POST["jelszo"] != $_POST["jelszoUjra"]) {
          throw new HibaException("A két jelszó nem egyezik!");
      }
      $queryUjfilm->bindParam("jelszo", $_POST["jelszo"], PDO::PARAM_STR);
      $queryUjfilm->execute();
 
      $uzenet = "Az új felhasználó sikeresen el lett mentve";
 
      header("Location: bejelentkezes.php");
      exit();
  } catch (PDOException $e) {
      $hiba = "Új felhasználó mentési hiba: " . $e->getMessage();
      error_log($hiba.PHP_EOL, 3, LOGFILE);
  } catch (HibaException $h) {
      $hiba = "Hiba: " . $h->getMessage();
      error_log($hiba.PHP_EOL, 3, LOGFILE);
  }
}
 
?>
 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="styles.css">
 
</head>
<body>
 
 
 
    <div class="container">
      <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
  
  <h2>REGISZTRÁCIÓ!</h2>
        <input type="text" name="felhasznalonev" placeholder="Felhasználónév/e-mail cím">
        <input type="password" name="jelszo" placeholder="Jelszó">
        <input type="password"  name="jelszoUjra" placeholder="Jelszó újra">

        <p>Van már fiókod?  <a href="bejelentkezes.php" style="text-decoration:none">Bejelentkezés</a></p>

       
  <?php
 
  if (!empty($hiba)){
    echo "<div class=\"error\">$hiba</div>\n";
  }
  if (!empty($uzenet)){
    echo "<div class=\"uzenet\">$uzenet</div>\n";
  }
 
 
  ?>
</select><br>
<input type="submit" value="Ment" name="submitRegisztracio" class="ment">
 
  </div>
   
</body>
</html>