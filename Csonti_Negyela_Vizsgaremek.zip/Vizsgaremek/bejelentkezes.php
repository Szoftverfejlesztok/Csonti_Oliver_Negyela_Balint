<?php
require_once("dbconnect.php");
$hiba = "";
$uzenet = "";

try {
    $sql = "SELECT id, felhasznalonev, jelszo FROM felhasznalok";
    $query = $dbconn->prepare($sql);
    $query->execute();
    $studiok = $query->fetchAll();
} catch (PDOException $e) {
    $hiba = "Felhasználói lekérdezési hiba: " . $e->getMessage();
    error_log($hiba . PHP_EOL, 3, LOGFILE);
}

if (!empty($dbconn) && 
    $_SERVER["REQUEST_METHOD"] == "POST" && 
    isset($_POST["submitBejelentkezes"])) {
    
    $felhasznalonev = $_POST["felhasznalonev"];
    $jelszo = $_POST["jelszo"];
    
    try {
       
        $sqlLogin = "SELECT * FROM felhasznalok WHERE felhasznalonev = :felhasznalonev AND jelszo = :jelszo";
        $queryLogin = $dbconn->prepare($sqlLogin);
        $queryLogin->bindParam("felhasznalonev", $felhasznalonev, PDO::PARAM_STR);
        $queryLogin->bindParam("jelszo", $jelszo, PDO::PARAM_STR);
        $queryLogin->execute();
        
        if ($queryLogin->rowCount() > 0) {

            header("Location: listanezet.php");
            exit();
        } else {
            $hiba = "Hibás felhasználónév vagy jelszó!";
        }
    } catch (PDOException $e) {
        $hiba = "Bejelentkezési hiba: " . $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Bejelentkezés</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
  <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">

    <h2>ÜDVÖZÖLJÜK!</h2>
    <input type="text" name="felhasznalonev" placeholder="Felhasználónév/e-mail cím" required>
    <input type="password" name="jelszo" placeholder="Jelszó" required>


    
    <p>Még nincs fiókod? <a href="Reg.php" style="text-decoration:none">Regisztráció</a></p>
    
    
    <?php if (!empty($hiba)) { echo "<div class='error'>$hiba</div>"; } ?>
    <div>
    <input type="submit" value="Ment" name="submitBejelentkezes" class="ment">
    </div>
  </form>
  </div>
</body>
</html>