<?php
require_once("dbconnect.php");

$hiba = "";
$uzenet = "";
$teendoId = $_GET['id'] ?? null;
$leiras = "";

// Teendő leírásának mentése
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitLeiras"])) {
    try {
        if (empty($_POST["leiras"])) {
            throw new Exception("Kérjük, adjon meg egy leírást!");
        }

        $sqlLeiras = "UPDATE lista SET leiras = :leiras WHERE id = :id";
        $queryLeiras = $dbconn->prepare($sqlLeiras);
        $queryLeiras->bindParam("leiras", $_POST["leiras"], PDO::PARAM_STR);
        $queryLeiras->bindParam("id", $teendoId, PDO::PARAM_INT);

        $queryLeiras->execute();

        $uzenet = "A leírás sikeresen el lett mentve.";
    } catch (PDOException $e) {
        $hiba = "Leírás mentési hiba: " . $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    } catch (Exception $e) {
        $hiba = $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    }
}

// Teendő adatainak lekérdezése
if ($teendoId) {
    try {
        $sqlTeendo = "SELECT listaelem, leiras FROM lista WHERE id = :id";
        $queryTeendo = $dbconn->prepare($sqlTeendo);
        $queryTeendo->bindParam("id", $teendoId, PDO::PARAM_INT);
        $queryTeendo->execute();
        $teendo = $queryTeendo->fetch(PDO::FETCH_ASSOC);
        if ($teendo) {
            $leiras = $teendo['leiras'] ?? '';
        } else {
            $hiba = "Teendő nem található.";
        }
    } catch (PDOException $e) {
        $hiba = "Teendő lekérdezési hiba: " . $e->getMessage();
        error_log($hiba . PHP_EOL, 3, LOGFILE);
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teendő Leírás</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2><?= htmlspecialchars($teendo['listaelem'] ?? 'Teendő') ?> Leírása</h2>
        <?php
        if (!empty($hiba)) {
            echo "<div class=\"error\">$hiba</div>\n";
        }
        if (!empty($uzenet)) {
            echo "<div class=\"uzenet\">$uzenet</div>\n";
        }
        ?>
        <form action="<?= $_SERVER["PHP_SELF"] . '?id=' . $teendoId ?>" method="post">
            <br>
            <textarea name="leiras" rows="5" placeholder="Írja ide a leírást..." required class="ment"><?= htmlspecialchars($leiras) ?></textarea>
            <input type="submit" value="Mentés" name="submitLeiras" class="ment">
        </form>

        <a href="listanezet.php" style="text-decoration:none">Vissza a listanézetre</a>
    </div>
</body>
</html>