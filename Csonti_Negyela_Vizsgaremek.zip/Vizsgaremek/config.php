<?php
// Futtatási paraméterek konstansokba kiemelve
define("DBTYPE","mysql");
define("DBHOST","localhost");
define("DBNAME","vizsgaremek");
define("DBUSER","root");
define("DBPASSWORD","");

define("LOGFILE","error.log");

?>