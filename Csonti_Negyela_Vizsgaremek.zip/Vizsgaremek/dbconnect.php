<?php
require_once("config.php");   // paraméterek beemelése (ha hibás, leáll a futás)
try {
  $dbconn = new PDO(DBTYPE.":".
    "host=".DBHOST.";".
    "dbname=".DBNAME.";".
    "charset=utf8",
    DBUSER,
    DBPASSWORD
  );
  $dbconn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e){
  $hiba = "Adatbázis kapcsolódási hiba: ".$e->getMessage();
  error_log($hiba.PHP_EOL,3,LOGFILE);
  //die();
}

?>